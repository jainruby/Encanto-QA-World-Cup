package BasePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeDriverService;
public class BasePage1 {
	public static String xPath_FilterExpandPanel = "//*[@data-mega-menu-id='megaMenuServices']";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 
		WebDriver driver = new ChromeDriver();
 
		String startURL = "https://www.nagarro.com";
		String currentURL = null;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		foo(driver,startURL);
		/* go to next page */
	}

	private static void foo(WebDriver driver, String startURL) {
		// TODO Auto-generated method stub
		driver.navigate().to(startURL);
	}
	public static boolean serviceButton(String action) throws Exception {
	
			
				WebDriver driver;
				Actions a = new Actions(driver); 

				  WebElement m=driver.findElement(By.xpath(xPath_FilterExpandPanel)); 
				 a.moveToElement(m).click().perform();
			}
				
							 
}
		
}
}

