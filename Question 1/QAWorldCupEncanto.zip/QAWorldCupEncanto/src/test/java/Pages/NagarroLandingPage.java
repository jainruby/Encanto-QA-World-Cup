package Pages;

public class NagarroLandingPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// --------------------------------------------------------------------------------------------------------------------------------
		// Navigate to the Nagarro
		
//		public WorkflowLandingPage navigateToWorkFlowLandingPage() throws Exception {
//
//			try {
//				// open hamburger menu
//				openMainMenu();
//
//				LibraryFunctions.isElementPresent(xPath_mnuAnalysisItemOption, 3);
//
//				if (BasePage.driver.findElement(By.xpath(xPath_mnuAnalysisItemOption)).getAttribute("class")
//						.contains("collapsed")
//						|| BasePage.driver.findElement(By.xpath(xPath_mnuAnalysisItemOption)).getAttribute("class")
//								.isEmpty()) {
//					UtilityFunctions.applicationWait(1000);
//					// Click on the feature Master menu option
//					BasePage.driver.findElement(By.xpath(xPath_mnuAnalysisItemOption)).click();
//				}
//
//				LibraryFunctions.isElementPresent(xPath_mnuWorkFlowMenuOption, 3);
//
//				UtilityFunctions.applicationWait(1000);
//
//				// Click on the feature sub menu option
//				BasePage.driver.findElement(By.xpath(xPath_mnuWorkFlowMenuOption)).click();
//
//			} catch (Exception e) {
//				log.error("Error occurred while navigating to WorkFlows Landing Page " + BasePage.currentMethodName);
//				throw e;
//			}
//			return new WorkflowLandingPage();
//		}

	}

}
